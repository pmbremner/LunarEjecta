// Declaration of regolith information

#ifndef LUNAREJECTA_REGOLITH_H
#define LUNAREJECTA_REGOLITH_H


#endif 